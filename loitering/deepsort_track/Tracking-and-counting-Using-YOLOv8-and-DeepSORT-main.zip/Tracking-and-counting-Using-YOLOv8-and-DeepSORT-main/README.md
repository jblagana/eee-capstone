# Tracking-and-counting-Using-YOLOv8-and-DeepSORT
Tracking and counting persons

Follow this Youtube video to run this code: https://youtu.be/Y2fyDYcfmBg

Clone this github repo: 

git clone https://github.com/AarohiSingla/Tracking-and-counting-Using-YOLOv8-and-DeepSORT.git

Open jupyter notebook and start working


![1](https://github.com/AarohiSingla/Tracking-and-counting-Using-YOLOv8-and-DeepSORT/assets/60029146/a1057b86-fcd7-412c-b7b0-583101cf91b6)




